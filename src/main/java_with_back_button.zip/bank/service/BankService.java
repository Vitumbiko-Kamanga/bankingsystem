package bank.service;

import bank.model.Account;
import bank.model.SavingsAccount;
import bank.model.Transaction;

import java.util.*;
import java.util.concurrent.*;

public class BankService {

    private final Map<String, Account> accounts = new ConcurrentHashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(5);

    public void addAccount(Account acc) {
        accounts.put(acc.getAccountId(), acc);
        FileService.saveAccount(acc.getAccountId(), acc.getAccountNumber(), acc.getOwner());
    }

    public void loadAccounts() {
        for (String line : FileService.readAccounts()) {
            String[] p = line.split(",");
            if (p.length >= 3) {
                accounts.put(p[0], new SavingsAccount(p[0], p[1], p[2], 0));
            }
        }
    }

    public Account getAccount(String id) {
        return accounts.get(id);
    }

    public Account getByAccountNumber(String accNo) {
        return accounts.values().stream()
                .filter(a -> a.getAccountNumber().equals(accNo))
                .findFirst().orElse(null);
    }

    public void deleteAccountFromCache(String accountId) {
        accounts.remove(accountId);
    }

    // ✅ SYNCHRONOUS: For Main.java UI thread
    public String deposit(String id, double amount) {
        Account acc = accounts.get(id);
        if (acc == null) return "❌ ERROR: Account not found";

        if (amount <= 0) return "❌ ERROR: Amount must be positive";

        acc.deposit(amount);
        FileService.saveTransaction(id, "DEPOSIT", amount, "Deposit");
        return "✅ Deposit successful: MWK " + String.format("%.2f", amount);
    }

    public String withdraw(String id, double amount) {
        Account acc = accounts.get(id);
        if (acc == null) return "❌ ERROR: Account not found";

        if (amount <= 0) return "❌ ERROR: Amount must be positive";

        try {
            double balance = calculateBalance(id);
            if (amount > balance) return "❌ ERROR: Insufficient funds (Balance: MWK " +
                    String.format("%.2f", balance) + ")";

            acc.withdraw(amount);
            FileService.saveTransaction(id, "WITHDRAWAL", amount, "Withdrawal");
            return "✅ Withdrawal successful: MWK " + String.format("%.2f", amount);
        } catch (Exception e) {
            return "❌ ERROR: " + e.getMessage();
        }
    }

    public String transfer(String fromId, String toAccNo, double amount) {
        Account from = accounts.get(fromId);
        Account to = getByAccountNumber(toAccNo);
        if (from == null) return "❌ ERROR: Sender account not found";
        if (to == null) return "❌ ERROR: Recipient '" + toAccNo + "' not found";

        if (from.getAccountNumber().equals(toAccNo))
            return "❌ ERROR: Cannot transfer to same account";

        if (amount <= 0) return "❌ ERROR: Amount must be positive";

        try {
            double fromBalance = calculateBalance(fromId);
            if (amount > fromBalance)
                return "❌ ERROR: Insufficient funds (Balance: MWK " +
                        String.format("%.2f", fromBalance) + ")";

            from.withdraw(amount);
            to.deposit(amount);

            // ✅ Save BOTH sides of transfer
            FileService.saveTransaction(from.getAccountId(), "TRANSFER", amount, "Sent to " + toAccNo);
            FileService.saveTransaction(to.getAccountId(), "TRANSFER", amount, "Received from " + fromId);

            return "✅ Transfer successful: MWK " + String.format("%.2f", amount) +
                    " → " + to.getOwner();
        } catch (Exception e) {
            return "❌ ERROR: " + e.getMessage();
        }
    }

    // ✅ Used by Main.java transfer dialog
    public String transferByAccountNumber(String accountId, String toAccountNumber, double amount) {
        return transfer(accountId, toAccountNumber, amount);
    }

    // ✅ FIXED: Accurate balance calculation using transactions
    public double calculateBalance(String accId) {
        return FileService.getAllTransactionsAsObjects().stream()
                .filter(t -> t.getAccountId().equals(accId))
                .mapToDouble(t -> switch (t.getType()) {
                    case DEPOSIT -> +t.getAmount();
                    case WITHDRAWAL -> -t.getAmount();
                    case TRANSFER -> 0.0;  // Transfers are recorded separately
                })
                .sum();
    }

    // ✅ Get account balance display string
    public String getBalanceDisplay(String accId) {
        double balance = calculateBalance(accId);
        return String.format("💰 Balance: MWK %.2f", balance);
    }

    // ✅ Get all accounts for admin
    public Collection<Account> getAllAccounts() {
        return new ArrayList<>(accounts.values());
    }

    // ✅ Admin: Get total bank balance
    public double getTotalBankBalance() {
        return accounts.values().stream()
                .mapToDouble(acc -> calculateBalance(acc.getAccountId()))
                .sum();
    }

    // ✅ Admin: Get summary stats
    public Map<Transaction.Type, Long> getTransactionStats() {
        return FileService.getAllTransactionsAsObjects().stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        Transaction::getType,
                        java.util.stream.Collectors.counting()
                ));
    }

    public void shutdown() {
        executor.shutdown();
    }
}